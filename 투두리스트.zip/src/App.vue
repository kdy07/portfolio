<script>
import TodoHeader from './components/TodoHeader.vue';
import TodoInput from './components/TodoInput.vue';
import TodoList from './components/TodoList.vue';

export default {
  components: {
    TodoHeader,
    TodoInput,
    TodoList,
  },
  data() {
    return {
      todo: [],
      current: 'all',
      searchQuery: '',
      tagFilter: '',
      categoryFilter: '',
      isDarkMode: false,
      editingId: null,
      sortBy: 'default',
    };
  },
  computed: {
    computedTodo() {
      let filtered = [...this.todo]; // 배열 복사
      if (this.searchQuery) {
        filtered = filtered.filter(v =>
          v.msg.toLowerCase().includes(this.searchQuery.toLowerCase()) ||
          (v.tags && v.tags.some(tag => tag.toLowerCase().includes(this.searchQuery.toLowerCase())))
        );
      }
      if (this.tagFilter) {
        filtered = filtered.filter(v => v.tags && v.tags.includes(this.tagFilter));
      }
      if (this.categoryFilter) {
        filtered = filtered.filter(v => v.category === this.categoryFilter);
      }
      if (this.current === 'all') {
        // No additional filtering
      } else if (this.current === 'completed') {
        filtered = filtered.filter(v => v.completed);
      } else if (this.current === 'active') {
        filtered = filtered.filter(v => !v.completed);
      }
      if (this.sortBy === 'name') {
        return filtered.sort((a, b) => a.msg.localeCompare(b.msg));
      } else if (this.sortBy === 'priority') {
        const priorityOrder = { high: 1, medium: 2, low: 3 };
        return filtered.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
      } else if (this.sortBy === 'dueDate') {
        return filtered.sort((a, b) => {
          const dateA = a.dueDate ? new Date(a.dueDate) : new Date('9999-12-31');
          const dateB = b.dueDate ? new Date(b.dueDate) : new Date('9999-12-31');
          return dateA - dateB;
        });
      }
      return filtered;
    },
    totalTodos() {
      return this.todo.length;
    },
    activeTodos() {
      return this.todo.filter(v => !v.completed).length;
    },
    allTags() {
      const tags = new Set();
      this.todo.forEach(item => item.tags && item.tags.forEach(tag => tags.add(tag)));
      return Array.from(tags);
    },
    reminders() {
      const today = new Date();
      return this.todo.filter(item => {
        if (!item.dueDate || item.completed) return false;
        const dueDate = new Date(item.dueDate);
        dueDate.setHours(0, 0, 0, 0);
        const diffDays = Math.ceil((dueDate - today) / (1000 * 60 * 60 * 24));
        return diffDays === 1;
      });
    },
    progress() {
      if (this.totalTodos === 0) return 0;
      return Math.round((1 - this.activeTodos / this.totalTodos) * 100);
    },
  },
  methods: {
    addTodo(inputMsg, priority = 'medium', dueDate = null, tags = [], category = '기타', recurrence = null) {
      const item = {
        id: Math.random(),
        msg: inputMsg,
        completed: false,
        priority,
        dueDate,
        tags,
        category,
        recurrence,
      };
      this.todo.push(item);
      this.saveToLocalStorage();
      this.updateRecurringTasks();
    },
    updateTab(tab) {
      this.current = tab;
    },
    deleteTodo(id) {
      this.todo = this.todo.filter(v => v.id !== id);
      this.saveToLocalStorage();
    },
    updateTodo(id) {
      this.todo = this.todo.map(v =>
        v.id === id ? { ...v, completed: !v.completed } : v
      );
      this.saveToLocalStorage();
      this.updateRecurringTasks();
    },
    clearCompleted() {
      this.todo = this.todo.filter(v => !v.completed);
      this.saveToLocalStorage();
    },
    startEditing(id) {
      this.editingId = id;
    },
    saveEdit(id, newMsg, newDueDate, newTags, newCategory, newRecurrence) {
      if (newMsg.trim()) {
        this.todo = this.todo.map(v =>
          v.id === id ? { ...v, msg: newMsg, dueDate: newDueDate, tags: newTags, category: newCategory, recurrence: newRecurrence } : v
        );
        this.saveToLocalStorage();
      }
      this.editingId = null;
      this.updateRecurringTasks();
    },
    updatePriority(id, priority) {
      this.todo = this.todo.map(v =>
        v.id === id ? { ...v, priority } : v
      );
      this.saveToLocalStorage();
    },
    duplicateTodo(id) {
      const item = this.todo.find(v => v.id === id);
      if (item) {
        const newItem = { ...item, id: Math.random(), completed: false };
        this.todo.push(newItem);
        this.saveToLocalStorage();
      }
    },
    clearAllTodos() {
      this.todo = [];
      this.saveToLocalStorage();
    },
    updateRecurringTasks() {
      const today = new Date();
      this.todo = this.todo.map(item => {
        if (item.recurrence && item.completed) {
          const dueDate = new Date(item.dueDate);
          let newDueDate;
          if (item.recurrence === 'daily') {
            newDueDate = new Date(dueDate.setDate(dueDate.getDate() + 1));
          } else if (item.recurrence === 'weekly') {
            newDueDate = new Date(dueDate.setDate(dueDate.getDate() + 7));
          } else if (item.recurrence === 'monthly') {
            newDueDate = new Date(dueDate.setMonth(dueDate.getMonth() + 1));
          }
          if (newDueDate && newDueDate > today) {
            return { ...item, completed: false, dueDate: newDueDate.toISOString().split('T')[0] };
          }
        }
        return item;
      });
      this.saveToLocalStorage();
    },
    saveToLocalStorage() {
      localStorage.setItem('todos', JSON.stringify(this.todo));
    },
    loadFromLocalStorage() {
      const savedTodos = localStorage.getItem('todos');
      if (savedTodos) {
        this.todo = JSON.parse(savedTodos);
      }
    },
    toggleDarkMode() {
      this.isDarkMode = !this.isDarkMode;
      document.body.classList.toggle('dark-mode', this.isDarkMode);
    },
    updateSort(sortBy) {
      this.sortBy = sortBy;
    },
    filterByTag(tag) {
      this.tagFilter = tag;
    },
    filterByCategory(category) {
      this.categoryFilter = category;
    },
  },
  mounted() {
    this.loadFromLocalStorage();
    setInterval(this.updateRecurringTasks, 60000);
  },
};
</script>

<template>
  <div class="todo" :class="{ 'todo--dark': isDarkMode }">
    <button class="todo__theme-btn" @click="toggleDarkMode">
      {{ isDarkMode ? '라이트 모드' : '다크 모드' }}
    </button>
    <TodoHeader :current="current" @update-tab="updateTab" />
    <div class="todo__controls">
      <div class="todo__search">
        <input
          v-model="searchQuery"
          type="text"
          class="todo__input-text"
          placeholder="작업 또는 태그 검색..."
          aria-label="Search tasks or tags"
        />
      </div>
      <div class="todo__sort">
        <select v-model="sortBy" @change="updateSort($event.target.value)" class="todo__sort-select" aria-label="Sort options">
          <option value="default">기본 정렬</option>
          <option value="name">이름순</option>
          <option value="priority">우선순위순</option>
          <option value="dueDate">마감일순</option>
        </select>
      </div>
      <div class="todo__tag-filter">
        <select @change="filterByTag($event.target.value)" class="todo__tag-select" aria-label="Filter by tag">
          <option value="">모든 태그</option>
          <option v-for="tag in allTags" :key="tag" :value="tag">{{ tag }}</option>
        </select>
      </div>
      <div class="todo__category-filter">
        <select @change="filterByCategory($event.target.value)" class="todo__category-select" aria-label="Filter by category">
          <option value="">모든 카테고리</option>
          <option v-for="category in categories" :key="category" :value="category">{{ category }}</option>
        </select>
      </div>
    </div>
    <div v-if="reminders.length > 0" class="todo__reminder" role="alert">
      <span>마감 1일 전: {{ reminders.map(r => r.msg).join(', ') }}</span>
    </div>
    <div class="todo__counter">
      <span>전체: {{ totalTodos }} | 미완료: {{ activeTodos }}</span>
      <div class="todo__progress">
        <div class="todo__progress-bar" :style="{ width: progress + '%' }"></div>
        <span>{{ progress }}% 완료</span>
      </div>
    </div>
    <TodoList
      :computed-todo="computedTodo"
      :editing-id="editingId"
      @delete-todo="deleteTodo"
      @update-todo="updateTodo"
      @start-editing="startEditing"
      @save-edit="saveEdit"
      @update-priority="updatePriority"
      @duplicate-todo="duplicateTodo"
    />
    <button class="todo__input-btn todo__clear-btn" @click="clearCompleted">
      완료된 작업 삭제
    </button>
    <button class="todo__input-btn todo__clear-all-btn" @click="clearAllTodos">
      모든 리스트 삭제
    </button>
    <TodoInput @add-todo="addTodo" :categories="categories" />
  </div>
</template>

<style>
.todo__controls {
  gap: 10px;
  flex-wrap: wrap;
  margin-bottom: 20px;
}

.todo__tag-select,
.todo__category-select,
.todo__sort-select {
  max-width: 100%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding: 12px 14px;
  border: 1px solid #d1d5db;
  border-radius: 16px;
  font-size: 15px;
  background-color: white;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.todo__tag-select:focus,
.todo__category-select:focus,
.todo__sort-select:focus {
  border-color: #7c3aed;
  box-shadow: 0 0 0 4px rgba(124, 58, 237, 0.15);
  outline: none;
}

.todo__reminder {
  background-color: #fee2e2;
  color: #991b1b;
  padding: 10px;
  border-radius: 12px;
  margin: 10px 0;
  font-size: 14px;
  text-align: center;
  animation: fadeIn 0.3s ease;
}

body.dark-mode .todo__reminder {
  background-color: #451a1a;
  color: #f87171;
}

.todo__clear-all-btn,
.todo__clear-btn {
  background: linear-gradient(135deg, #ef4444, #f87171);
  border: none;
  color: white;
  padding: 12px 20px;
  border-radius: 16px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  width: 100%;
  margin-top: 10px;
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
}

.todo__clear-all-btn:hover,
.todo__clear-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(239, 68, 68, 0.3);
  background: linear-gradient(135deg, #dc2626, #f43f5e);
}

body.dark-mode .todo__clear-all-btn,
body.dark-mode .todo__clear-btn {
  background: linear-gradient(135deg, #7f1d1d, #991b1b);
}

body.dark-mode .todo__clear-all-btn:hover,
body.dark-mode .todo__clear-btn:hover {
  box-shadow: 0 6px 16px rgba(127, 29, 29, 0.3);
  background: linear-gradient(135deg, #451a1a, #7f1d1d);
}

.todo__counter {
  text-align: center;
  margin: 24px 0;
  font-size: 15px;
  color: #6b7280;
  font-weight: 500;
}

body.dark-mode .todo__counter {
  color: #d1d5db;
}

.todo__progress {
  margin-top: 10px;
  width: 100%;
  background-color: #e5e7eb;
  border-radius: 12px;
  overflow: hidden;
}

body.dark-mode .todo__progress {
  background-color: #3f3f5a;
}

.todo__progress-bar {
  height: 10px;
  background: linear-gradient(135deg, #7c3aed, #a78bfa);
  transition: width 0.3s ease;
}

body.dark-mode .todo__progress-bar {
  background: linear-gradient(135deg, #4b5563, #6b7280);
}

.todo__progress span {
  display: block;
  font-size: 14px;
  margin-top: 5px;
  color: #6b7280;
}

body.dark-mode .todo__progress span {
  color: #d1d5db;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}
</style>