<script>
export default {
  props: {
    computedTodo: {
      type: Array,
      default() {
        return [];
      },
    },
    editingId: {
      type: Number,
      default: null,
    },
  },
  data() {
    return {
      editMsg: '',
      editDueDate: '',
      editTags: '',
      editCategory: '',
      editRecurrence: '',
    };
  },
  methods: {
    deleteTodo(id) {
      this.$emit('delete-todo', id);
    },
    updateTodo(id) {
      this.$emit('update-todo', id);
    },
    startEditing(item) {
      this.editMsg = item.msg;
      this.editDueDate = item.dueDate || '';
      this.editTags = item.tags ? item.tags.join(', ') : '';
      this.editCategory = item.category || '기타';
      this.editRecurrence = item.recurrence || null;
      this.$emit('start-editing', item.id);
    },
    saveEdit(id) {
      if (this.editMsg.trim()) {
        const tagsArray = this.editTags
          ? this.editTags.split(',').map(tag => tag.trim()).filter(tag => tag)
          : [];
        this.$emit('save-edit', id, this.editMsg, this.editDueDate || null, tagsArray, this.editCategory, this.editRecurrence);
      }
    },
    updatePriority(id, priority) {
      this.$emit('update-priority', id, priority);
    },
    duplicateTodo(id) {
      this.$emit('duplicate-todo', id);
    },
    isOverdue(dueDate) {
      if (!dueDate) return false;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      return new Date(dueDate) < today;
    },
  },
};
</script>

<template>
  <transition-group
    name="todo-item"
    tag="div"
    class="todo__list"
  >
    <div
      v-for="item in computedTodo"
      :key="item.id"
      class="todo__item"
      :class="{
        'todo__item--completed': item.completed,
        'todo__item--priority-high': item.priority === 'high',
        'todo__item--priority-medium': item.priority === 'medium',
        'todo__item--priority-low': item.priority === 'low',
        'todo__item--overdue': isOverdue(item.dueDate) && !item.completed
      }"
      aria-label="Todo item"
    >
      <input
        type="checkbox"
        :id="'chk' + item.id"
        :checked="item.completed"
        @click="updateTodo(item.id)"
        class="todo__checkbox"
        aria-label="Mark task as completed"
      />
      <label :for="'chk' + item.id" class="todo__checkbox-label"></label>
      <div v-if="editingId !== item.id" class="todo__item-content" @click="startEditing(item)">
        <span class="todo__item-text">{{ item.msg }}</span>
        <div class="todo__item-meta">
          <span v-if="item.dueDate" class="todo__item-due">마감: {{ item.dueDate }}</span>
          <span v-if="item.tags && item.tags.length" class="todo__item-tags">
            #{{ item.tags.join(' #') }}
          </span>
          <span class="todo__item-category">{{ item.category }}</span>
          <span v-if="item.recurrence" class="todo__item-recurrence">
            (반복: {{ item.recurrence === 'daily' ? '매일' : item.recurrence === 'weekly' ? '매주' : '매월' }})
          </span>
        </div>
      </div>
      <div v-else-if="editingId === item.id" class="todo__edit-form">
        <input
          v-model="editMsg"
          type="text"
          class="todo__input-text todo__edit-input"
          @keydown.enter="saveEdit(item.id)"
          @blur="saveEdit(item.id)"
          aria-label="Edit task description"
        />
        <input
          v-model="editDueDate"
          type="date"
          class="todo__input-text todo__due-date"
          aria-label="Edit due date"
        />
        <input
          v-model="editTags"
          type="text"
          class="todo__input-text todo__tags-input"
          placeholder="태그 (쉼표로 구분)"
          aria-label="Edit tags"
        />
        <select v-model="editCategory" class="todo__category-select" aria-label="Edit category">
          <option v-for="cat in ['개인', '직장', '학습', '기타']" :key="cat" :value="cat">{{ cat }}</option>
        </select>
        <select v-model="editRecurrence" class="todo__recurrence-select" aria-label="Edit recurrence">
          <option value="null">반복 없음</option>
          <option value="daily">매일</option>
          <option value="weekly">매주</option>
          <option value="monthly">매월</option>
        </select>
      </div>
      <select
        :value="item.priority"
        class="todo__priority-select"
        @change="updatePriority(item.id, $event.target.value)"
        aria-label="Set priority"
      >
        <option value="high">높음</option>
        <option value="medium">중간</option>
        <option value="low">낮음</option>
      </select>
      <span
        class="material-symbols-outlined todo__duplicate-icon"
        @click="duplicateTodo(item.id)"
        aria-label="Duplicate task"
      >
        content_copy
      </span>
      <span
        class="material-symbols-outlined todo__delete-icon"
        @click="deleteTodo(item.id)"
        aria-label="Delete task"
      >
        delete
      </span>
    </div>
    <div v-if="computedTodo.length === 0" class="todo__item--no">
      <p>할일 목록이 없습니다.</p>
    </div>
  </transition-group>
</template>

<style>
.todo__item {
  gap: 10px;
  padding: 12px;
  border-radius: 12px;
  background-color: #f9fafb;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

body.dark-mode .todo__item {
  background-color: #2d2d44;
}

.todo__item:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

body.dark-mode .todo__item:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

.todo__item-content {
  flex-grow: 1;
  cursor: pointer;
}

.todo__item-meta {
  gap: 8px;
  margin-top: 4px;
}

.todo__item-category {
  font-size: 13px;
  color: #6b7280;
  background-color: #e5e7eb;
  padding: 4px 12px;
  border-radius: 12px;
  font-weight: 500;
}

body.dark-mode .todo__item-category {
  color: #d1d5db;
  background-color: #3f3f5a;
}

.todo__item-recurrence {
  font-size: 13px;
  color: #6b7280;
  background-color: #e5e7eb;
  padding: 4px 12px;
  border-radius: 12px;
  font-weight: 500;
}

body.dark-mode .todo__item-recurrence {
  color: #d1d5db;
  background-color: #3f3f5a;
}

.todo__duplicate-icon {
  flex-shrink: 0;
  color: #4b5563;
  font-size: 24px;
  cursor: pointer;
  transition: transform 0.3s ease, color 0.3s ease;
}

.todo__duplicate-icon:hover {
  color: #7c3aed;
  transform: scale(1.3);
}

body.dark-mode .todo__duplicate-icon {
  color: #d1d5db;
}

body.dark-mode .todo__duplicate-icon:hover {
  color: #a78bfa;
}

.todo__delete-icon {
  flex-shrink: 0;
  color: #f43f5e;
  font-size: 24px;
  cursor: pointer;
  transition: transform 0.3s ease, color 0.3s ease;
}

.todo__delete-icon:hover {
  color: #e11d48;
  transform: scale(1.3);
}

body.dark-mode .todo__delete-icon {
  color: #f87171;
}

body.dark-mode .todo__delete-icon:hover {
  color: #dc2626;
}

/* 우선순위 색상 배경 */
.todo__item--priority-high {
  background-color: #fee2e2;
  border-left: 5px solid #f43f5e;
}

body.dark-mode .todo__item--priority-high {
  background-color: #451a1a;
  border-left-color: #f87171;
}

.todo__item--priority-medium {
  background-color: #fefcbf;
  border-left: 5px solid #fb923c;
}

body.dark-mode .todo__item--priority-medium {
  background-color: #4c3a1a;
  border-left-color: #fdba74;
}

.todo__item--priority-low {
  background-color: #d1fae5;
  border-left: 5px solid #34d399;
}

body.dark-mode .todo__item--priority-low {
  background-color: #1a3c2e;
  border-left-color: #6ee7b7;
}
</style>