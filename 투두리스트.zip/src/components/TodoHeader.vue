<script>
export default {
  props: {
    current: {
      type: String,
      default() {
        return 'all';
      },
    },
  },
  emits: ['update-tab'],
  methods: {
    updateTab(tab) {
      this.$emit('update-tab', tab);
    },
  },
};
</script>

<template>
  <div class="todo__title">
    <h1 class="todo__text">Todo List</h1>
    <ul class="todo__tab">
      <li
        role="button"
        tabindex="0"
        :class="{ 'todo__tab--active': current === 'all' }"
        @click="updateTab('all')"
        @keydown.enter.space="updateTab('all')"
      >전체</li>
      <li
        role="button"
        tabindex="0"
        :class="{ 'todo__tab--active': current === 'completed' }"
        @click="updateTab('completed')"
        @keydown.enter.space="updateTab('completed')"
      >완료</li>
      <li
        role="button"
        tabindex="0"
        :class="{ 'todo__tab--active': current === 'active' }"
        @click="updateTab('active')"
        @keydown.enter.space="updateTab('active')"
      >미완료</li>
    </ul>
  </div>
</template>

<style scoped>
.todo__tab {
  display: flex;
  justify-content: center;
  gap: 14px;
  margin-top: 20px;
}

.todo__tab li {
  padding: 10px 20px;
  border-radius: 16px;
  cursor: pointer;
  background-color: #f3f4f6;
  color: #4b5563;
  font-weight: 500;
  font-size: 15px;
  transition: all 0.2s ease;
}

.todo__tab li:hover {
  background-color: #e5e7eb;
}

.todo__tab--active {
  background: linear-gradient(135deg, #7c3aed, #a78bfa);
  color: white;
  font-weight: 600;
}
</style>