<script>
export default {
  props: {
    categories: {
      type: Array,
      default() {
        return ['기타'];
      },
    },
  },
  data() {
    return {
      inputMsg: '',
      priority: 'medium',
      dueDate: '',
      tags: '',
      category: '기타',
      recurrence: null,
    };
  },
  emits: ['addTodo'],
  methods: {
    addTodo() {
      if (this.inputMsg.trim() === '') {
        return; // 공백 입력 시 무시
      }
      const tagsArray = this.tags ? this.tags.split(',').map(tag => tag.trim()).filter(tag => tag) : [];
      this.$emit('addTodo', this.inputMsg, this.priority, this.dueDate || null, tagsArray, this.category, this.recurrence);
      this.inputMsg = '';
      this.priority = 'medium';
      this.dueDate = '';
      this.tags = '';
      this.category = '기타';
      this.recurrence = null;
    },
  },
};
</script>

<template>
  <div class="todo__input">
    <input
      v-model="inputMsg"
      type="text"
      class="todo__input-text"
      placeholder="할 일을 입력하세요."
      @keydown.enter="addTodo"
      aria-label="Enter new task"
    />
    <input
      v-model="dueDate"
      type="date"
      class="todo__input-text todo__due-date"
      placeholder="마감일"
      aria-label="Set due date"
    />
    <input
      v-model="tags"
      type="text"
      class="todo__input-text todo__tags-input"
      placeholder="태그 (쉼표로 구분)"
      aria-label="Enter tags"
    />
    <select v-model="priority" class="todo__priority-select" aria-label="Set priority">
      <option value="high">높음</option>
      <option value="medium">중간</option>
      <option value="low">낮음</option>
    </select>
    <select v-model="category" class="todo__category-select" aria-label="Set category">
      <option v-for="cat in categories" :key="cat" :value="cat">{{ cat }}</option>
    </select>
    <select v-model="recurrence" class="todo__recurrence-select" aria-label="Set recurrence">
      <option value="null">반복 없음</option>
      <option value="daily">매일</option>
      <option value="weekly">매주</option>
      <option value="monthly">매월</option>
    </select>
    <button class="todo__input-btn" @click="addTodo" aria-label="Add task">
      등록
    </button>
  </div>
</template>

<style>
.todo__input {
  gap: 10px;
  flex-wrap: wrap;
}

.todo__input-text,
.todo__due-date,
.todo__tags-input {
  padding: 12px 14px;
  border: 1px solid #d1d5db;
  border-radius: 16px;
  font-size: 15px;
  background-color: white;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.todo__input-text:focus,
.todo__due-date:focus,
.todo__tags-input:focus {
  border-color: #7c3aed;
  box-shadow: 0 0 0 4px rgba(124, 58, 237, 0.15);
  outline: none;
}

.todo__category-select,
.todo__recurrence-select,
.todo__priority-select {
  padding: 12px 14px;
  border: 1px solid #d1d5db;
  border-radius: 16px;
  font-size: 15px;
  background-color: white;
  flex: 0 0 100px;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

.todo__category-select:focus,
.todo__recurrence-select:focus,
.todo__priority-select:focus {
  border-color: #7c3aed;
  box-shadow: 0 0 0 4px rgba(124, 58, 237, 0.15);
  outline: none;
}

.todo__input-btn {
  background: linear-gradient(135deg, #7c3aed, #a78bfa);
  border: none;
  color: white;
  padding: 12px 20px;
  border-radius: 16px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.3s ease, box-shadow 0.3s ease, background 0.3s ease;
}

.todo__input-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(124, 58, 237, 0.3);
  background: linear-gradient(135deg, #6b21a8, #9333ea);
}

body.dark-mode .todo__input-btn {
  background: linear-gradient(135deg, #4b5563, #6b7280);
}

body.dark-mode .todo__input-btn:hover {
  box-shadow: 0 6px 16px rgba(75, 85, 99, 0.3);
  background: linear-gradient(135deg, #374151, #4b5563);
}
</style>