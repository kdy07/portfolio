
# 셋업
import os,pygame,sys,random, time, math
from pygame.locals import *

# 현재 파일의 디렉토리로 작업 디렉토리 설정
os.chdir(os.path.dirname(os.path.abspath(__file__)))

pygame.init()
clock = pygame.time.Clock()
pygame.display.set_caption("Space Invaders")
SCREEN_WIDTH, SCREEN_HEIGHT = 1024, 768
screen = pygame.display.set_mode((SCREEN_WIDTH ,SCREEN_HEIGHT))

score = 0
shots =0
hits = 0
misses = 0

font = pygame.font.Font(None, 20) # 기본 폰트, 크기:20
last_badguys_spawm_time = 0     # 악당이 마지막에 나온 시각을 기록
last_badguys_spawm_time2 = 0

background_image = pygame.image.load("image/background.png").convert()
background_image = pygame.transform.smoothscale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

badguy_image = pygame.image.load("image/bad_banana.png").convert()
badguy_image.set_colorkey((0,0,0))

badguy_image2 = pygame.image.load("image/bad_banana2.png").convert()
badguy_image2.set_colorkey((0,0,0))

fighter_image = pygame.image.load("image/fighter_back.png").convert_alpha()
fighter_image.set_colorkey((255,255,255))
fighter_image = pygame.transform.scale(fighter_image, (120, 120))

missile_image = pygame.image.load("image/banana.png").convert_alpha()
missile_image.set_colorkey((255,255,255))
missile_image = pygame.transform.scale(missile_image, (30, 30))

super_missile_image = pygame.image.load("image/super_missile.png").convert_alpha()
super_missile_image = pygame.transform.scale(super_missile_image, (200, 200))

explosion_image = pygame.image.load("image/explosion.png").convert_alpha()
explosion_image = pygame.transform.scale(explosion_image, (512, SCREEN_HEIGHT))

GAME_OVER = pygame.image.load("image\gameover.png").convert()
GAME_OVER= pygame.transform.scale(GAME_OVER, (400, 400))

# 클래스
class BaseBadguy:
    def __init__(self, image):
        self.x = random.randint(0, SCREEN_WIDTH - 100)
        self.y = -100
        d = (math.pi / 2) * random.random() - (math.pi / 4)
        speed = random.randint(2, 6)
        self.dx = math.sin(d) * speed
        self.dy = math.cos(d) * speed
        self.image = image

    def move(self):
        if self.x < 0 or self.x > SCREEN_WIDTH - int(SCREEN_WIDTH * 0.05):
            self.dx *= -1
        self.x += self.dx
        self.dy += 0.1
        self.y += self.dy

    def draw(self):
        screen.blit(self.image, (self.x, self.y))

    def off_screen(self):
        return self.y > SCREEN_HEIGHT

    def touching(self, missile):
        return (self.x + 35 - missile.x) ** 2 + (self.y + 22 - missile.y) ** 2 < 1225

    def score(self):
        global score
        score += 100

class Badguy(BaseBadguy):
    def __init__(self):
        super().__init__(badguy_image)

class Badguy2(BaseBadguy):
    def __init__(self):
        super().__init__(badguy_image2)

class Fighter :
    def __init__(self) :
        self.x = 320
        self.last_super_shot_score = 0
        self.last_clone_shot_score = 0
        self.clones = []
        self.explosion = None  # 필살기 추가

    def move(self) :
        if pressed_keys[K_LEFT] and self.x > 0:
            self.x -= int(SCREEN_WIDTH * 0.02)
        if pressed_keys[K_RIGHT] and self.x < SCREEN_WIDTH - fighter_image.get_width():
            self.x += int(SCREEN_WIDTH * 0.02)

    def draw(self):
        screen.blit(fighter_image, (self.x, SCREEN_HEIGHT - fighter_image.get_height()))

    def fire(self) :
        global shots
        shots += 1
        missiles.append(Missile(self.x + 60))
        missiles.append(Missile(self.x + 30))

    def hit_by(self, badguy):
        return(
            badguy.y > SCREEN_HEIGHT - fighter_image.get_height() and
            badguy.x > self.x - 15 and
            badguy.x < self.x + fighter_image.get_width() - 35
        )
    
    def super_missile(self):
        global shots
        if score >= self.last_super_shot_score + 1000:  # 1000점 증가할 때마다 실행
            self.last_super_shot_score = score  # 마지막 발사 점수 갱신
            shots += 3
            missiles.append(SuperMissile(self.x + 60, 0))   # 중앙
            missiles.append(SuperMissile(self.x + 40, -12))  # 왼쪽 대각선
            missiles.append(SuperMissile(self.x + 80, 12))   # 오른쪽 대각선

    def clone(self):
        if score >= self.last_clone_shot_score + 2000 and len(self.clones) < 3:  # 필살기 발동 조건
            self.last_clone_shot_score = score  # 마지막 발사 점수 갱신
            self.clones.append(Clone(self.x))  # 복제본 생성

    def update_clones(self):
        for clone in self.clones:
            clone.move(self.x + 100)  # 클론이 플레이어의 위치를 따라가도록 업데이트
            clone.draw()  # 클론을 그리기

    def explosion_skill(self):
        global shots
        if score >= 10000:  
            if not self.explosion:  # 이미 필살기가 발동되었으면 새로 생성 안함
                self.explosion = Explosion()
                shots += 1  # 미사일 발사 수 증가

    def update_explosion(self):
        if self.explosion:
            self.explosion.update()  # 폭발 상태 업데이트
            self.explosion.apply_effect(badguys, badguys2)  # 적 제거
            self.explosion.draw()  # 폭발 효과 그리기

class Missile :
    def __init__(self, x) :
        self.x = x
        self.y = 668
    def move(self) :
        self.y -= 8
    def off_screen(self) :
        return self.y < -8
    def draw(self) :
        screen.blit(missile_image, (self.x-4, self.y))

class SuperMissile:
    def __init__(self, x, dx=0):  # dx 추가 (좌우 이동 값)
        self.x = x
        self.y = 668
        self.dx = dx - 10  # 좌우 이동 속도 추가
        self.dy = -5  # 기존보다 강한 속도

    def move(self):
        self.y += self.dy
        self.x += self.dx  # 좌우 이동 추가
        if self.x <= 0 or self.x >= SCREEN_WIDTH:
            self.dx *= -1  # 방향 반전

    def off_screen(self):
        return self.y < -8   # 화면 밖이면 삭제

    def draw(self):
        screen.blit(super_missile_image, (self.x - 4, self.y)) 

class Clone:
    def __init__(self, x):
        self.x = x
        self.y = SCREEN_HEIGHT - fighter_image.get_height()
        self.life_time = 5  # 복제본이 살아있는 시간 (초)
        self.last_shot_time = 0  # 마지막 미사일 발사 시간
        
    def move(self, player_x):
        self.x = player_x  
        self.y = SCREEN_HEIGHT - fighter_image.get_height()

    def fire(self):
        if time.time() - self.last_shot_time > 0.3:  # 일정 간격마다 미사일 발사
            missiles.append(Missile(self.x + 60))  # 복제본이 미사일을 발사
            missiles.append(Missile(self.x + 30))  # 복제본이 미사일을 발사
            self.last_shot_time = time.time()

    def draw(self):
        # 복제본의 이미지를 플레이어처럼 그리기
        screen.blit(fighter_image, (self.x, self.y))

    def update(self):
        self.life_time -= 1 / 60  # 1초마다 1초 감소
        if self.life_time <= 0:
            return True  # 복제본이 사라졌으면 True 리턴
        return False

class Explosion:
    def __init__(self):
        self.x = SCREEN_WIDTH // 2  # 화면 중앙
        self.y = -50  # 시작 위치를 화면 위쪽에 설정
        self.radius = 200  # 폭발 범위 (원 크기)
        self.exploding = True
        self.time_to_explode = 10.0  # 폭발 시간 (초)
        self.start_time = time.time()
        self.explosion_image = explosion_image

    def update(self):
        if self.exploding:
            self.y -= 5  # 폭발이 떨어지는 느낌을 주기 위해 Y값을 계속 증가시킴
        if time.time() - self.start_time > self.time_to_explode:
            self.exploding = False

    def draw(self):
        if self.exploding:
            screen.blit(self.explosion_image, (self.x - 200, self.y + 200))  # 폭발 이미지가 떨어지도록 위치 조정

    def apply_effect(self, badguys, badguys2):
        if self.exploding:
            for badguy in badguys[:]:
                if (badguy.x - self.x) ** 2 + (badguy.y - self.y) ** 2 < self.radius ** 2:
                    badguys.remove(badguy)
            for badguy in badguys2[:]:
                if (badguy.x - self.x) ** 2 + (badguy.y - self.y) ** 2 < self.radius ** 2:
                    badguys2.remove(badguy)

def reset_game() : # 게임을 다시 초기화
    global badguys, missiles, fighter, score, shots, hits, misses
    
    badguys = []
    missiles = []
    fighter = Fighter()
    score = 0
    hits = 0
    misses = 0
    shots = 0   

def game_over_screen(): # 게임 오버
        screen.blit(GAME_OVER, (170,200))

        screen.blit(font.render(str(shots), True, (0, 0, 0)), (330, 460))
        screen.blit(font.render(str(score), True, (0, 0, 0)), (330, 530))
        screen.blit(font.render(str(hits), True, (0, 0, 0)), (520, 460))
        screen.blit(font.render(str(misses), True, (0, 0, 0)), (520, 530))
         
        pygame.display.update()
        pygame.time.wait(2000)

        badguys.clear()
        badguys2.clear()

        waiting_for_keypress = True
        while waiting_for_keypress:
            screen.blit(GAME_OVER, (170, 200))  
            pygame.display.update()
            for event in pygame.event.get():
                if event.type == QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == KEYDOWN:
                    waiting_for_keypress = False
        reset_game()

# 리스트
badguys2 = []
badguys = []
fighter = Fighter()
missiles = []

# 게임루프
while 1 :
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == QUIT :
            sys.exit()
        if event.type == KEYDOWN and event.key == K_SPACE :
            fighter.fire()
        if event.type == KEYDOWN and event.key == K_LSHIFT :
            fighter.explosion_skill()
        
    pressed_keys = pygame.key.get_pressed()

    fighter.super_missile()
    screen.blit(background_image, (0, 0))
    fighter.move()
    fighter.draw()
    fighter.clone() 
    fighter.update_clones()
    fighter.update_explosion()
    
    if time.time() - last_badguys_spawm_time > 0.5 :
        badguys.append(Badguy())
        last_badguys_spawm_time = time.time()

    if time.time() - last_badguys_spawm_time2 > 0.5 :
        badguys2.append(Badguy2())
        last_badguys_spawm_time2 = time.time()

    i = 0
    while i < len(badguys): #배드가이 움직임
        badguys[i].move()
        badguys[i].draw()
        if badguys[i].off_screen():
            del badguys[i]
            i -= 1
        i += 1

    i = 0
    while i < len(badguys2): #배드가이2 움직임
        badguys2[i].move()
        badguys2[i].draw()
        if badguys2[i].off_screen():
            del badguys2[i]
            i -= 1
        i += 1
    
    i = 0
    while i < len(missiles): #미사일 움직임
        missiles[i].move()
        missiles[i].draw()
        if missiles[i].off_screen():
            del missiles[i]
            misses += 1
            i -= 1
        i += 1

    i = 0
    while i < len(badguys): #배드가이 충돌
        j = 0
        while j < len(missiles):
            if badguys[i].touching(missiles[j]):
                badguys[i].score()
                hits += 1
                if isinstance(missiles[j], Missile):  # 일반 미사일만 삭제
                    del missiles[j]
                del badguys[i]
                i -= 1
                break 
            j += 1
        i += 1
    
    i = 0
    while i < len(badguys2): #배드가이2 충돌
        j = 0
        while j < len(missiles):
            if badguys2[i].touching(missiles[j]):
                badguys2[i].score()
                hits += 1
                if isinstance(missiles[j], Missile):  # 일반 미사일만 삭제
                    del missiles[j]
                del badguys2[i]
                
                i -= 1
                break 
            j += 1
        i += 1
    
    i = 0
    while i < len(fighter.clones):
        clone = fighter.clones[i]
        clone.fire()  # 복제본 미사일 발사
        clone.draw()  # 복제본 그리기
        if clone.update():  # 복제본이 시간 초과하면 제거
            del fighter.clones[i]
            i -= 1
        i += 1

    for badguy in badguys: # 게임 오버 충돌 체크
        if fighter.hit_by(badguy):
            game_over_screen()
            break

    for badguy in badguys2: # 게임 오버 충돌 체크2
        if fighter.hit_by(badguy):
            game_over_screen()
            break

    screen.blit(font.render("Score: "+ str(score), True, (255,255,255)), (5,5))

    pygame.display.update()