import streamlit as st
import joblib
from konlpy.tag import Okt
import os
from sklearn.feature_extraction.text import TfidfVectorizer

# -----------------------------
# 1. 형태소 분석기 & 전처리
# -----------------------------
okt = Okt()
stopwords = ['은', '는', '이', '가', '을', '를', '에', '의', '도', '로', '으로']

def tokenize(text):
    tokens = okt.morphs(text, stem=True)
    return [t for t in tokens if t not in stopwords]

def preprocess(text):
    return " ".join(tokenize(text))

# -----------------------------
# 2. 모델 & 벡터 불러오기
# -----------------------------
@st.cache_resource
def load_model():
    BASE_DIR = os.path.dirname(__file__)
    model_path = os.path.join(BASE_DIR, "korean_sentiment_model.pkl")
    vectorizer_path = os.path.join(BASE_DIR, "korean_vectorizer.pkl")

    model = joblib.load(model_path)

    # 벡터라이저는 다시 정의 후 단어장만 복원 (tokenizer 함수 포함 불가능)
    with open(vectorizer_path, "rb") as f:
        vectorizer: TfidfVectorizer = joblib.load(f)

    # 벡터라이저의 tokenizer를 다시 설정
    vectorizer.tokenizer = tokenize

    return model, vectorizer

# 모델, 벡터 불러오기
model, vectorizer = load_model()

# -----------------------------
# 3. 감정 예측 함수
# -----------------------------
def predict_sentiment(text):
    cleaned = preprocess(text)
    X = vectorizer.transform([cleaned])
    pred = model.predict(X)[0]
    prob = model.predict_proba(X)[0]
    label = "긍정 😊" if pred == 1 else "부정 😠"
    confidence = prob[1] if pred == 1 else prob[0]
    return label, confidence

# -----------------------------
# 4. Streamlit UI
# -----------------------------
st.set_page_config(page_title="한글 감정 분석기", layout="centered")

st.markdown(
    """
    <h1 style='text-align: center; color: #6C63FF;'>🔍 한글 감정 분석기</h1>
    <p style='text-align: center;'>문장을 입력하면 AI가 감정을 분석해줍니다!</p>
    """,
    unsafe_allow_html=True
)

st.markdown("---")

user_input = st.text_area("✍️ 문장을 입력하세요:", height=150)

if st.button("감정 분석"):
    if user_input.strip():
        label, confidence = predict_sentiment(user_input)
        pred = 1 if label.startswith("긍정") else 0

        # 색상과 이모지 지정
        color = "green" if pred == 1 else "red"
        emoji = "😊" if pred == 1 else "😠"

        # 결과 출력
        st.markdown(f"<h3 style='color:{color};'>결과: {label} {emoji}</h3>", unsafe_allow_html=True)
    else:
        st.warning("문장을 입력해주세요.")


st.markdown("---")
st.caption("📌 학습 데이터: 네이버 쇼핑 리뷰 데이터셋 (bab2min/corpus (GitHub))")
