import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from konlpy.tag import Okt
from sklearn.metrics import classification_report
import joblib

# -----------------------------
# 1. 데이터 불러오기 (Naver 쇼핑 리뷰)
# -----------------------------
url = "https://raw.githubusercontent.com/bab2min/corpus/master/sentiment/naver_shopping.txt"
df = pd.read_csv(url, sep='\t', header=None)
df.columns = ['label_score', 'document']  # ✅ 컬럼 2개만 있음

# -----------------------------
# 2. 라벨 재정의 및 전처리
# -----------------------------
df = df[df['label_score'] != 3]  # 중립 제거
df['label'] = df['label_score'].apply(lambda x: 1 if x > 3 else 0)
df = df[['document', 'label']].dropna()  # 결측 제거

# -----------------------------
# 3. 학습/테스트 데이터 분할
# -----------------------------
train_data, test_data = train_test_split(df, test_size=0.2, random_state=42)

# -----------------------------
# 4. 형태소 분석기 + 불용어 제거
# -----------------------------
okt = Okt()
stopwords = ['은', '는', '이', '가', '을', '를', '에', '의', '도', '로', '으로']

def tokenize(text):
    tokens = okt.morphs(str(text), stem=True)
    return [t for t in tokens if t not in stopwords]

# -----------------------------
# 5. TF-IDF 벡터화
# -----------------------------
vectorizer = TfidfVectorizer(tokenizer=tokenize, max_features=10000)

X_train = vectorizer.fit_transform(train_data['document'])
y_train = train_data['label']

X_test = vectorizer.transform(test_data['document'])
y_test = test_data['label']

# -----------------------------
# 6. 모델 학습
# -----------------------------
model = LogisticRegression()
model.fit(X_train, y_train)

# -----------------------------
# 7. 평가
# -----------------------------
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))

# -----------------------------
# 8. 모델 및 벡터 저장
# -----------------------------
joblib.dump(model, "korean_sentiment_model.pkl")
joblib.dump(vectorizer, "korean_vectorizer.pkl")
print("✅ 모델과 벡터 저장 완료")
